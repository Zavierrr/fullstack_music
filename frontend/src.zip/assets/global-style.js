// 全局风格定义 是最重要的
// 老板 + 设计师  风格是样式的灵魂 
export default {
    "theme-color": "#C20C0C",
    "font-color": "#111",
    "font-size-s": "12px",
    "font-color-light": "#f1f1f1",
    "font-color-desc": "#2e30e0",
}
