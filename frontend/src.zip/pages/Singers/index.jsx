import React from 'react'

export default function Singers() {
  return (
    <div>
      Singers
    </div>
  )
}
