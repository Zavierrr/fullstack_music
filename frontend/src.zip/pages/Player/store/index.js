import reducer from './reducer'
import * as actionCreators from './actionCreators'
import * as constants from './constants'
// index.js 颜值担当
export {
    reducer,
    actionCreators,
    constants
}